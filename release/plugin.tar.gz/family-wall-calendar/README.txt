Family Wall Calendar 1.0.0
A plugin for Home Screens. Install it from the editor: Plugins > Install from URL, or copy this folder to data/plugins/family-wall-calendar/ on the hub.
Source and docs: https://github.com/cyberbandit1998/homescreens
